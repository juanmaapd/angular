import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-get',
  templateUrl: './product-get.component.html',
  styleUrls: ['./product-get.component.css']
})
export class ProductGetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
